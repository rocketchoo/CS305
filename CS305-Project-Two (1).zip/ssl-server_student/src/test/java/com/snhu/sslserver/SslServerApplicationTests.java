import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
@WebMvcTest // Only loads web layer
class MyControllerTest {
		@Autowired
		private MockMvc mockMvc;
		@Test
		void testSecureEndpoint() throws Exception {
				mockMvc.perform(MockMvcRequestBuilders.get("/my-secure-endpoint"))
							 .andExpect(status().isOk()); // Check for a 200 OK response 
		}
}
